<?php

namespace Silber\Bouncer\Database\Scope;

use Illuminate\Database\Eloquent\Scope as EloquentScope;

class TenantScope extends BaseTenantScope implements EloquentScope
{
    //
}
