---
title: Get User Dms
category: User
order: 6
---

# `getUserDms`

```php
$client->user->getUserDms($parameters);
```

## Description



## Parameters

No Parameters

## Response

Returns a list of DM channel objects.

Can Return:

* DM channel
