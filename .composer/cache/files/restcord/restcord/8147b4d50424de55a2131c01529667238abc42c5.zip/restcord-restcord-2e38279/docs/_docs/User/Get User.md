---
title: Get User
category: User
order: 2
---

# `getUser`

```php
$client->user->getUser($parameters);
```

## Description



## Parameters


Name | Type | Required | Default
--- | --- | --- | ---
user.id | snowflake | true | *null*

## Response

Returns a user object for a given user ID.

Can Return:

* user
