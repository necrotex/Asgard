<?php

namespace SocialiteProviders\Manager\Exception;

class InvalidArgumentException extends \InvalidArgumentException
{
}
