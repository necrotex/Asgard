<?php

namespace SocialiteProviders\Manager\Exception;

class MissingConfigException extends \Exception
{
}
