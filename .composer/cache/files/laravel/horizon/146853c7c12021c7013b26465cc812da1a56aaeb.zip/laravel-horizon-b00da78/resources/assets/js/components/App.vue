<script type="text/ecmascript-6">
    export default {
        name: 'App'
    };
</script>

<template>
    <router-view/>
</template>

