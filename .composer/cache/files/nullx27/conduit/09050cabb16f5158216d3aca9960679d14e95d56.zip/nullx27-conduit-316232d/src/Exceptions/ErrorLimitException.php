<?php

namespace Conduit\Exceptions;

class ErrorLimitException extends \Exception
{

}