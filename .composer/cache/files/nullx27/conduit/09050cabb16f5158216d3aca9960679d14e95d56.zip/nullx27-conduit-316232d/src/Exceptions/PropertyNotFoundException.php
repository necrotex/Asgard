<?php

namespace Conduit\Exceptions;

class PropertyNotFoundException extends \Exception
{

}