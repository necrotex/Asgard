<?php

namespace Conduit\Exceptions;

class HttpStatusException extends \Exception
{

}