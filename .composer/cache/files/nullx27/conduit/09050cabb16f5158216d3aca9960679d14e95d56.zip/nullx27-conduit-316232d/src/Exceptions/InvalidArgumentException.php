<?php

namespace Conduit\Exceptions;

class InvalidArgumentException extends \Exception
{

}