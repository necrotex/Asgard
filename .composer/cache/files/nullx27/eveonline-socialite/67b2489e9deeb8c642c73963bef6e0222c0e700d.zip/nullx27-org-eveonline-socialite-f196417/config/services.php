<?php

return [
    'eveonline' => [
        'client_id' => env('EVEONLINE_CLIENT_ID'),
        'client_secret' => env('EVEONLINE_CLIENT_SECRET'),
        'redirect' => env('EVEONLINE_REDIRECT'),
    ]
];